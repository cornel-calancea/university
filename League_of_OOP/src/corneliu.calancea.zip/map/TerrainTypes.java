package map;

public enum TerrainTypes {
  Land,
  Volcanic,
  Desert,
  Woods
}
