package main;

import game.Game;
import input.GameIOLoader;
import input.GameInput;
import magician.Magician;

import java.io.IOException;

public final class Main {
  private Main() {
  }

  public static void main(final String[] args) throws IOException, CloneNotSupportedException {
    GameIOLoader gameIOLoader = new GameIOLoader(args[0], args[1]);
    GameInput gameInput = gameIOLoader.loadInput();
    Game game = new Game(gameInput);
    game.run();
    gameIOLoader.loadOutput(Magician.getReport());
  }
}
