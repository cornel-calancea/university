package angel;

public enum AngelType {
    DamageAngel,
    DarkAngel,
    TheDoomer,
    Dracula,
    GoodBoy,
    LevelUpAngel,
    LifeGiver,
    SmallAngel,
    Spawner,
    XPAngel
}
