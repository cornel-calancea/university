Copyright Calancea Corneliu - 312CD

Programul dat implementeaza jocul tetris conform conditiei propuse, primește harta, numărul de mutări și piesele și efectuează mișcările corespunzătoare. 
