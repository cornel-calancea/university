//Copyright Corneliu Calancea 312CD
#include <stdio.h>
#include <math.h>

void display_map(unsigned long long h) {
  int i = 0, n;
  for (n = 63; n >= 0; --n) {
    if ((i % 8 == 0) && (i != 0)) {
      printf("\n");
    }
    if ((h & (1LL << n)) == 0) {
      printf(".");
      h = (h - (1LL << n));
    } else {
      printf("#");
    }
    ++i;
  }
  printf("\n\n");
  return;
}

float get_score(unsigned long long map, int completed_lines) {
  int n = 0, zeros = 0;
  float score;
  for (n = 63; n >= 0; --n) {
    if ((map & (1LL << n)) == 0) {
      ++zeros;
    }
  }
  score = sqrt(zeros) + pow(1.25, completed_lines);

  return score;
}

int has_space(unsigned long long map, unsigned long long figura) {
  return (map & figura) == 0;
}

int has_space_right(unsigned long long map, unsigned long long figura) {
  return (map & (figura >> 1)) == 0;
}

int has_space_left(unsigned long long map, unsigned long long figura) {
  return (map & (figura << 1)) == 0;
}

int is_not_on_left_border(unsigned long long figura) {
  unsigned long long left_border = -9187201950435737472;
  return ((figura & left_border) ^ left_border) == left_border;
}

int is_not_on_right_border(unsigned long long fig) {
  unsigned long long right_border = 72340172838076673;
  return ((fig & right_border) ^ right_border) == right_border;
}

// returneaza figura_input shiftata in dreapta
unsigned long long shift_right(unsigned long long map,
                               unsigned long long figura, int miscari,
                               int* miscari_facute) {
  int move_count = 0;
  while ((move_count < miscari) && has_space_right(map, figura) &&
         is_not_on_right_border(figura)) {
    figura = figura >> 1;
    move_count++;
  }
  *miscari_facute = move_count;
  return figura;
}

// returneaza figura_input shiftata in stanga
unsigned long long shift_left(unsigned long long map, unsigned long long figura,
                              int miscari, int* miscari_facute) {
  int move_count = 0;
  while ((move_count < miscari) && has_space_left(map, figura) &&
         is_not_on_left_border(figura)) {
    figura = figura << 1;
    move_count++;
  }
  *miscari_facute = move_count;
  return figura;
}

unsigned long long mutare(unsigned long long map,
                          unsigned long long figura_input, int* miscari) {
  unsigned long long figura, figura_old;
  figura = figura_input << 56;
  int miscari_facute = 0;
  int k = 0;

  for (k = 0; k < 8; k++) {
    if (has_space(map, figura)) {
      if (miscari[k] > 0) {  // piesa trebuie mutata in dreapta
        figura = shift_right(map, figura, miscari[k], &miscari_facute);
        figura_input = (figura_input >> miscari_facute);
        display_map(map + figura);
      } else {
        figura = shift_left(map, figura, -miscari[k], &miscari_facute);
        figura_input = (figura_input << miscari_facute);
        display_map(map + figura);
      }
      if (k < 7) {
        figura_old = figura;
        figura = figura >> 8;
      }
      if (k == 0) {
        // copie al doilea rand al figurii de 2 randuri la prima miscare
        figura = figura_input << 48;
      }
    } else {
      return (map + figura_old);
    }
  }
  return (map | figura);
}

int count_lines(unsigned long long map) {
  unsigned long long Mask = 255;
  int i = 0, complete_lines = 0;
  for (i = 0; i < 8; i++) {
    if ((map & Mask) == Mask) {
      complete_lines++;
    }
    map = map >> 8;
  }
  return complete_lines;
}

unsigned long long remove_lines(unsigned long long map) {
  int k = 0;
  unsigned long long mask = 0xffffffffffffffff;
  unsigned long long upper_map = 0;
  for (k = 7; k >= 0; k--) {
    // Verifica daca randul e complet
    if (((mask >> 56) & (map >> (8 * k))) == 255) {
      if (k != 0) {
        // clear upper lines
        map = ((map << ((8 - k) * 8)) >> ((8 - k) * 8));
      } else {
        map = 0;
      }
      upper_map = (upper_map >> 8);
      map = (map | upper_map);
    } else {
      // Clears bottom part of the map
      upper_map = ((map >> (k * 8)) << (8 * k));
    }
  }

  return map;
}

int main() {
  unsigned long long map = 0;
  int nrmutari, p, complete_lines = 0, i = 0;
  scanf("%llu", &map);
  scanf("%d", &nrmutari);
  display_map(map);

  for (p = nrmutari; p > 0; --p) {
    unsigned long long figura_input;
    int miscari[8];
    scanf("%llu", &figura_input);
    if (!(has_space(map, figura_input << 56))) {
      display_map(map);
      break;
    }

    for (i = 0; i < 8; ++i) {
      scanf("%d", &miscari[i]);
    }

    map = mutare(map, figura_input, miscari);
    if (count_lines(map) != 0) {
      complete_lines = complete_lines + count_lines(map);
      map = remove_lines(map);
      display_map(map);
    }
  }

  printf("GAME OVER!\n");
  printf("Score:%.2f\n", get_score(map, complete_lines));

  return 0;
}
